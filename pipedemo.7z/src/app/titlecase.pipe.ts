import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'titlecase'
})
export class TitlecasePipe implements PipeTransform {

  transform(value: string, ...args: string[]): string {
    let first:string;
    let rem:string;
    first=value.slice(0,1).toUpperCase();
    rem= value.slice(1).toLowerCase();
    return first+rem;
  }

}
